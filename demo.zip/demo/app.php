<?php
set_include_path(
	implode(PATH_SEPARATOR, array(
		'./lib',
		get_include_path(),
	))
);
include_once ('autoloader.php');
$host = 'localhost';
$port = 9092;
$topic = 'test';
$producer = new Kafka_Producer($host, $port, Kafka_Encoder::COMPRESSION_NONE);
$msg="hello all";
$messages=array();
$messages[0]=$msg;
$bytes = $producer->send($messages, $topic);
printf("\nSuccessfully sent %d messages (%d bytes)\n\n", count($messages), $bytes);

?>
